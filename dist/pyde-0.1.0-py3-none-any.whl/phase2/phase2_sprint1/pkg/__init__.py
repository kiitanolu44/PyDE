from .a import foo as foo
from .b import bar as bar, bar_check as bar_check
