__all__ = ["foo"]


def foo() -> None:
    pass


def bar() -> None:
    pass


def baz() -> None:
    pass
