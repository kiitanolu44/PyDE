def func() -> None:
    return "v2"
