def foo() -> str:
    return "A"
